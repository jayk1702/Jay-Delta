## Wether meter information

#### Reference Link: 
* [Weather Meter Hookup Guide](https://learn.sparkfun.com/tutorials/weather-meter-hookup-guide?_ga=2.263568005.825707439.1625984668-619345068.1624809911)


### RJ11 Top View Male Plug
![RJ11 Top View Male Plug](RJ11_Top_View.jpg)
 Pin No | Wire Color | Description 
--------- | --------- | -------------- 
1 | x | NC
2 | BLACK | GND (Wind Direction)
3 | RED | GND (Wind Speed)
4 | YELLOW | WIND SPEED
5 | GREEN | WIND DIR
6 | x | NC

### Sensor Voltage with respect to wind angle
 Sr No | Wind Angle (Degrees) | Wind Direction | Sensor Voltage (mV)
--------- | --------- | -------------- | ---------------------------
1 | 0 | N | 2510
2| 45 | NE | 1470
3| 90| E | 295
4| 135| SE | 587
5| 180| S | 910
6| 225| SW | 2020
7| 270| W | 3045
8| 315| NW | 2855


![Sensor Voltage Chart](WindAngleVsSensorVoltage.png)
![Wind Directions](compassrose.jpg)

### Example code for ESP32
```C


#define WIND_DIR 2

int windAngleDegrees = 0;
String windDirection = "";

void setup() 
{
  Serial.begin(115200);
}


void loop()
{

  int sensor_val_mv = 0;
  for(int i = 0; i<20; i++)
  {
    sensor_val_mv += analogReadMilliVolts(WIND_DIR);
    delay(5);
  }
  sensor_val_mv = sensor_val_mv / 20;
  windAngleDegrees = getWindAngle(sensor_val_mv);
  String windDir = getWindDirectionFromWindAngle(windAngleDegrees);

  Serial.print(sensor_val_mv);
  Serial.print("\t : ");
  Serial.print(windAngleDegrees);
  Serial.print("\t : ");  
  Serial.println(windDir);
  delay(500);
}

int getWindAngle(int vin) 
{
  String windAngle = "";
  if (vin < 310) windAngle = "90"; //E
  else if (vin < 610) windAngle = "135"; //SE
  else if (vin < 1000) windAngle = "180"; //S
  else if (vin < 1500) windAngle = "45"; //NE
  else if (vin < 2100) windAngle = "225"; //SW
  else if (vin < 2600) windAngle = "0"; //N
  else if (vin < 2910) windAngle = "315"; //NW
  else if (vin < 3100) windAngle = "270"; //W
  else windAngle = "0";

  return windAngle.toInt();
}

String getWindDirectionFromWindAngle(int WindAngle)
{
  switch(WindAngle)
  {
    case 0:
    windDirection = "N";
    break;

    case 45:
    windDirection = "NE";
    break;

    case 90:
    windDirection = "E";
    break;

    case 135:
    windDirection = "SE";
    break;

    case 180:
    windDirection = "S";
    break;

    case 225:
    windDirection = "SW";
    break;

    case 270:
    windDirection = "W";
    break;

    case 315:
    windDirection = "NW";
    break;

    default:
    windDirection = "NA";
  }

  return windDirection;
}


```

### Rain Tick Sensor
```C
-------------------------
|   RJ 11 Male Pin OUT  |
| 1 | 2 | 3 | 4 | 5 | 6 |
--------         --------
        |_NOTCH_|
  1: NC
  2: GND
  3: GND
  4: WIND SPEED (Yellow) || RAIN (GREEN)
  5: WIND Direction (Grren)
  6: NC
  ```