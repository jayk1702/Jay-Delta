# Weather Station



### Installing 4G USB modem to Raspberry Pi

#### REF: [Link](https://bellergy.com/3-installing-4g-usb-modem-to-raspberry-pi/)

### Check if the USB device is loaded
```sh
lsusb | grep "D-Link"
bus 001 Device 006: ID 2001:7e3d D-Link Corp. Mobile Connect

```

### Check if modem USB device is loaded in dmesg
```
dmseg | gerp 7e3d
[  15.8505559] usb 1-1.1: New USB device found, idVendor=2001, idProduct=7e3d, bcdDevice= 2.28
```
### Install wvdial
#### If the modem has been loaded but it didn’t dial up. You can install the wvdial.
```sh
sudo apt-get install wvdial
```

### Edit the `wvdial.conf` file
```sh
sudo pico /etc/wvdial.conf
```

#### add following lines to it
```sh
[Dialer Defaults]
Init1 = ATZ
Init2 = ATQ0 V1 E1 S0=0 &C1 &D1 +FCLASS=0
Modem Type = Analog Modem
Baud = 9600
New PPPD = yes
Modem = /dev/ttyUSB1
ISDN = 0
Phone = *99#
Password = internet
Username = internet
Stupid Mode = on
```

### Testing the dial up:
```sh
sudo wvdial

----------------
--> WvDial: Internet dialer version 1.61
--> Initializing modem.
--> Sending: ATZ
OK
--> Sending: ATQ0 V1 E1 S0=0
OK
--> Modem initialized.
--> Sending: ATDT*99#
--> Waiting for carrier.
ATDT*99#
CONNECT 150000000
--> Carrier detected.  Starting PPP immediately.
--> Starting pppd at Sun Oct 18 14:45:08 2020
--> Pid of pppd: 1329
--> Using interface ppp0
--> pppd: X/?[01]X/?[01]
--> local  IP address xxx.xxx.xxx.xxx
--> pppd: X/?[01]X/?[01]
--> remote IP address xxx.xxx.xxx.xxx
--> pppd: X/?[01]X/?[01]
--> primary   DNS address xxx.xxx.xxx.xxx
--> pppd: X/?[01]X/?[01]
--> secondary DNS address xxx.xxx.xxx.xxx
--> pppd: X/?[01]X/?[01]
```

### Create the service for auto dial up

```sh
sudo pico /etc/systemd/system/wvdial.service
```
#### add following liones to file
```sh
[Unit]
Description=wvdial

[Service]
ExecStart=/usr/bin/wvdial
Restart=on-failure
RestartSec=5
```

#### Add udev rule
Add the code to the 99-com.rules file. It will call the wvdial.service when the USB modem loaded.

```sh
sudo pico /etc/udev/rules.d/99-com.rules
```
#### Add following lines to the file (do not overwrite)
```sh
SUBSYSTEM=="tty", KERNEL=="ttyUSB1", TAG+="systemd", ENV{SYSTEMD_WANTS}+="wvdial.service"
```

### Reboot the pi

### Testing the connection
Run the command:
```sh
ifconfig
```
If the modem runs correctly, you can find the ppp0 output:

```sh
ppp0: flags=4305<UP,POINTOPOINT,RUNNING,NOARP,MULTICAST>  mtu 1500
        inet xxx.xxx.xxx.xxx  netmask 255.255.255.255  destination 10.64.64.64
        ppp  txqueuelen 3  (Point-to-Point Protocol)
        RX packets 11065  bytes 1348146 (1.2 MiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 12168  bytes 1585065 (1.5 MiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
```

### Try pinging the 8.8.8.8
```sh
ping 8.8.8.8
PING 8.8.8.8 (8.8.8.8) 56(84) bytes of data
64 bytes from 8.8.8.8 icmp_seq=1 ttl=58 time=206 ms
```