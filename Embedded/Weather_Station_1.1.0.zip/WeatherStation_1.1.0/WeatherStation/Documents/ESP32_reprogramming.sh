#!/bin/bash
ESP32_RESET=22
ESP32_BOOT=23
BAUD_RATE=921600
CHIP_ID=esp32s3

echo "NEW Reprogramming Session Started" > reprogramming_log.txt 2>&1

date >> reprogramming_log.txt 2>&1

# Function to Stop itrap-ccm.service
stop_itrap_ccm_service()
{

    echo "Stopping itrap-ccm.service to make sure no conflicts over serial port for reprogramming" >> reprogramming_log.txt 2>&1
    sudo systemctl stop itrap-ccm.service
    sleep 0.01
    
}

# Function to Stop itrap-ccm.service
start_itrap_ccm_service()
{

    echo "Re Start itrap-ccm.service after reprogramming" >> reprogramming_log.txt 2>&1
    sudo systemctl start itrap-ccm.service
    sleep 0.01
    
}

# Function to put ESP32 into UART download mode
enter_uart_download_mode()
{

    echo "Forcing ESP32 to enter into UART Download mode" >> reprogramming_log.txt 2>&1

    # Set ESP32_BOOT to high (op dh)
    pinctrl set $ESP32_BOOT op dh
    sleep 0.01

    # Set ESP32_RESET to high (op dh)
    pinctrl set $ESP32_RESET op dh
    sleep 0.01

    # Set ESP32_RESET to low (op dl)
    pinctrl set $ESP32_RESET op dl
    sleep 0.01

    # Set ESP32_BOOT to low (op dl)
    pinctrl set $ESP32_BOOT op dl
    sleep 0.01

    echo "ESP32 is now in UART download mode." >> reprogramming_log.txt 2>&1
}

# Function to reset the ESP32
reset_esp32()
{
    echo "Reseting ESP32" >> reprogramming_log.txt 2>&1

    # Set ESP32_RESET to high (op dh)
    pinctrl set $ESP32_RESET op dh
    sleep 0.01

    # Set ESP32_RESET to low (op dl)
    pinctrl set $ESP32_RESET op dl
    sleep 0.01

    echo "ESP32 has been reset." >> reprogramming_log.txt 2>&1
}

# Check if the correct number of arguments are passed
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <port> <hex_file>" >> reprogramming_log.txt 2>&1
    exit 1
fi


# Get the port and hex file from the arguments
PORT=$1
HEX_FILE=$2

# Call a function to stop itrap-ccm.service
stop_itrap_ccm_service

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null
then
    echo "Python 3 is not installed. Please install Python 3 first." >> reprogramming_log.txt 2>&1
    exit 1
fi

# Check if Python 3 is installed
#if command -v python3 &>/dev/null; then
#    echo "Python 3 is already installed." >> reprogramming_log.txt 2>&1
#else
#    echo "Python 3 is not installed. Installing..." >> reprogramming_log.txt 2>&1
#    sudo apt update
#    sudo apt install python3 -y
#    echo "Python 3 has been installed." >> reprogramming_log.txt 2>&1
#fi

# Check if virtualenv is installed
if ! command -v python3 -m venv &> /dev/null
then
    echo "virtualenv is not installed. Installing it now..." >> reprogramming_log.txt 2>&1
    sudo apt install python3-pip
#    python3 -m pip install --upgrade pip
    python3 -m pip install virtualenv
fi

# Check if the 'python3' virtual environment exists
if [ ! -d "venv_python3" ]; then
    python3 -m venv venv_python3
    echo "Virtual environment 'venv_python3' created." >> reprogramming_log.txt 2>&1
else
    echo "Virtual environment 'venv_python3' already exists." >> reprogramming_log.txt 2>&1
fi

# Activate the virtual environment
# For Linux/macOS
echo "Activating Virtual environment" >> reprogramming_log.txt 2>&1
source venv_python3/bin/activate

echo "Virtual environment 'venv_python3' has been activated." >> reprogramming_log.txt 2>&1

# Check if esptool is installed
if ! pip show esptool > /dev/null; then
    echo "esptool not found, installing..." >> reprogramming_log.txt 2>&1
    pip3 install esptool
    echo "esptool installed." >> reprogramming_log.txt 2>&1
else
    echo "esptool is already installed." >> reprogramming_log.txt 2>&1
fi

# Call a function to force ESP32 into UART download mode
enter_uart_download_mode

echo "Flashing $HEX_FILE .." >> reprogramming_log.txt 2>&1

# Flash the ESP32 with the provided port and hex file, redirect output to reprogramming_log.txt
esptool.py --chip $CHIP_ID --port "$PORT" --baud $BAUD_RATE write_flash -z 0x10000 "$HEX_FILE" >> reprogramming_log.txt 2>&1
#esptool.py --port "/dev/ttyS0" write_flash -z 0x10000 "Blink_500.ino.bin"

echo "Flashing attempt completed. Output has been written to reprogramming_log.txt." >> reprogramming_log.txt 2>&1

# Reset ESP32
reset_esp32

# Deactivate the virtual environment
deactivate

# Call a function to start itrap-ccm.service
start_itrap_ccm_service

echo "Virtual environment venv_python3 has been deactivated." >> reprogramming_log.txt 2>&1

echo "Done with ReProgramming. Check for reprogramming_log.txt in this directory for reprogramming trace...!"

