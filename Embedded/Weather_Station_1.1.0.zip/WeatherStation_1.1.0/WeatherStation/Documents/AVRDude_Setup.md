## Installing and configuring `avrdude`

#### Reference Link: 
* [Building AVRDUDE for Linux](https://github.com/avrdudes/avrdude/wiki/Building-AVRDUDE-for-Linux)
* [How to Program an AVR/Arduino using the Raspberry Pi GPIO](https://ozzmaker.com/program-avr-using-raspberry-pi-gpio/)

### Prerequisites
### To uninstall avrdude
```sh
sudo dpkg --purge avrdude
```

### Update
```sh
sudo apt-get update
sudo apt-get upgrade
```
#### To build AVRDUDE for Linux, you need to install the following packages.
```sh
sudo apt-get install build-essential git cmake flex bison pkg-config libelf-dev libusb-dev libhidapi-dev libftdi1-dev libreadline-dev libserialport-dev libgpiod-dev
```

Minimum required version for CMake is 3.14.

### Build Instructions
To build AVRDUDE for Linux, run the following commands:
```sh
git clone https://github.com/avrdudes/avrdude.git
cd avrdude

```
Enable `LINUXGPIO` or `LINUXSPI` support, add the CMake options `-DHAVE_LINUXGPIO=1` and `-DHAVE_LINUXSPI=1`
```sh
cmake -D CMAKE_BUILD_TYPE=RelWithDebInfo -D HAVE_LINUXGPIO=1 -D HAVE_LINUXSPI=1 -B build_linux
```

Build `avrdude`
```sh
cmake --build build_linux
```

### Installation
To install a local build on your system, run the following commands:
```sh
sudo cmake --build build_linux --target install
```
### Verify installed avrdude
```sh
which avrdude
```

Expected output
```
/usr/local/bin/avrdude
```

### Configuration of avrdude
Now we need to tell avrdude to use the GPIO and we need to let it know what GPIO pins to use. This can be done by editing the config file

```sh
sudo nano /usr/local/etc/avrdude.conf
```

Look for `linuxgpio` and you should see commented in this section

```sh
# #------------------------------------------------------------
# # linuxgpio
# #------------------------------------------------------------
#
# programmer
#  id                   = "linuxgpio";
#  desc                 = "Linux sysfs/libgpiod to bitbang GPIO lines";
#  type                 = "linuxgpio";
#  prog_modes           = PM_ISP;
#  connection_type      = linuxgpio;
#  reset = ?;
#  sck   = ?;
#  mosi  = ?;
#  miso  = ?;
#;
```
Uncomment and change pins as follwoing
```sh
# #------------------------------------------------------------
# # linuxgpio
# #------------------------------------------------------------

 programmer
     id                   = "linuxgpio";
     desc                 = "Linux sysfs/libgpiod to bitbang GPIO lines";
     type                 = "linuxgpio";
     prog_modes           = PM_ISP;
     connection_type      = linuxgpio;
     reset                = 13;
     sck                  = 11;
     sdo                  = 10;
     sdi                  = 9;
;

```


## Raspberry Pi and AVR uC hookup guide
The image below shows how to connect a Raspberry Pi and an  Arduino UNO. click the image to make it larger

![Raspberry pi pinout](Rpi_Pinout.png)

![Hookup Guide](https://ozzmaker.com/wp-content/uploads/2016/03/RaspberryPiArduino2.png)

Note: above image for reference only, we are using RPi GPIO-13 for AVR reset

## For Arduino Pro Mini
![Pro Mini pinout](Arduino_Pro_Mini.png)

 AVR Pins | RPi GPIO | Physical RPi Pin 
--------- | --------- | --------------
RESET | GPIO-13 | Pin 33
SCK(13) | GPIO-11 | Pin 23
MISO(12) | GPIO-09 | Pin 21
MOSI(11) | GPIO-10 | Pin 19
VCC | 3V3 | Pin 1
GND | GND | Pin 6

### Quick Test
If everything is hooked up correctly you should now be about to communicate between the Raspberry Pi and Arduino/AVR. (Some Nano board has device signature `atmega328pb`)

```sh
sudo avrdude -c linuxgpio -p atmega328p -v

```
Expected output
```sh
Avrdude version 8.0
Copyright see https://github.com/avrdudes/avrdude/blob/main/AUTHORS

System wide configuration file is /usr/local/etc/avrdude.conf
User configuration file /root/.avrduderc does not exist

using libgpiod for linuxgpio
Using port            : gpiochip0
Using programmer      : linuxgpio
AVR part              : ATmega328P
Programming modes     : SPM, ISP, HVPP, debugWIRE
Programmer type       : linuxgpio
Description           : Linux sysfs/libgpiod to bitbang GPIO lines
Pin assignment        : libgpiod
  RESET  = 13
  SCK    = 11
  SDO    = 10
  SDI    = 9

AVR device initialized and ready to accept instructions
Device signature = 1E 95 0F (ATmega328P, ATA6614Q, LGT8F328P)

Avrdude done.  Thank you.
```

## Flash prebuilt hex file to AVR
```
sudo avrdude -c linuxgpio -p atmega328p -v -U flash:w:<path/to/hexfile.hex>:i
```

Note: Some arduino nano board has chip `atmega328pb`

```sh
sudo avrdude -c linuxgpio -p atmega328pb -v -U flash:w:/temp/WeatherStationMini.ino.hex:i
Avrdude version 8.0
Copyright see https://github.com/avrdudes/avrdude/blob/main/AUTHORS

System wide configuration file is /usr/local/etc/avrdude.conf
User configuration file /root/.avrduderc does not exist

using libgpiod for linuxgpio
Using port            : gpiochip0
Using programmer      : linuxgpio
AVR part              : ATmega328PB
Programming modes     : SPM, ISP, HVPP, debugWIRE
Programmer type       : linuxgpio
Description           : Linux sysfs/libgpiod to bitbang GPIO lines
Pin assignment        : libgpiod
  RESET  = 13
  SCK    = 11
  SDO    = 10
  SDI    = 9

AVR device initialized and ready to accept instructions
Device signature = 1E 95 16 (ATmega328PB)
Auto-erasing chip as flash memory needs programming (-U flash:w:...)
specify the -D option to disable this feature
Erased chip
Reading 21438 bytes for flash from input file WeatherStationMini.ino.hex
in 1 section [0, 0x53bd]: 168 pages and 66 pad bytes
Writing 21438 bytes to flash
Writing | ################################################## | 100% 5.06 s 
3 | ################################################## | 100% 4.42 s 
21438 bytes of flash verified

Avrdude done.  Thank you.
```


