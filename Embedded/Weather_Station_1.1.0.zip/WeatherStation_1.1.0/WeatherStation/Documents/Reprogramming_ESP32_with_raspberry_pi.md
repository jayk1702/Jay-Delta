# Flashing ESP32 with Raspberry pi using native UART

## Tools required
* Python3
* Virtual environment
* esptool.py
* [ESP32_reprogramming.sh](ESP32_reprogramming.sh)

### Prepare Rpi and ESP32 as per following table
Sr No | [Rpi pins](https://pinout.xyz/pinout/pin11_gpio17/) | [ESP32 pins](https://randomnerdtutorials.com/esp32-s3-devkitc-pinout-guide/)
| ------ | ------ | ------
1 | 5V | 5V
2 | GND | GND
3 | UART_TXD | U0_RXD
4 | UART_RXD | U0_TXD
5* | GPIO_22 | RESET
6* | GPIO_23 | GPIO_0 (BOOT)

Note: ESP reset and auto enter into UART download HW logic implemented using N channel mosfet
![ESP32 Reset Logic](ESP32_reset_logic.png)
### Copy your hex/bin  file to raspberry pi using sftp
```sh
sftp dt_rpi_9xxx

sftp> put <bin_file_name>
```
### Run [ESP32_reprogramming.sh](ESP32_reprogramming.sh) manually
```sh
./ESP32_reprogramming.sh <port> <bin_file_name>
```
example:
```sh
./ESP32_reprogramming.sh "/dev/ttyS0" "Blink_100.ino.bin"
```

### Take a look at `reprogramming_log.txt` for logs
```
cat reprogramming_log.txt

```

### [ESP32_reprogramming.sh](ESP32_reprogramming.sh) does the following jobs

This script essentially automates setting up the environment, installing necessary tools, and flashing the ESP32 with a provided hex file while logging the entire process.

- Initialization:

    Defines variables for GPIO pins (ESP32_RESET, ESP32_BOOT), baud rate, and chip ID.
    Starts a new reprogramming session and logs it to reprogramming_log.txt.
    Logs the current date and time to the log file.

- Argument Check:

    Ensures that exactly two arguments are passed (port and hex file), otherwise prints usage instructions and exits.

- Check for Python 3:

    Verifies if Python 3 is installed. If not, it logs an error message and exits.

- Check for Virtual Environment (virtualenv):

    Checks if virtualenv is installed. If not, installs it using pip3.

- Virtual Environment Creation:

    Checks if a virtual environment named venv_python3 exists. If not, it creates the environment and logs the creation.

- Activate Virtual Environment:

    Activates the venv_python3 virtual environment and logs the activation.

- Check for esptool:

    Checks if esptool is installed in the virtual environment. If not, it installs esptool using pip3 and logs the installation.

- Forcing ESP32 into UART download mode:

    Configures the Raspberry Pi GPIO pins to put the ESP32 into download mode for flashing.
    The pins are toggled to prepare the ESP32 for the flashing process.

- Flashing the ESP32:

    Uses esptool.py to flash the provided hex file to the ESP32.
    Logs the flashing attempt and its results.

- Reset ESP32:

    Resets the ESP32 by toggling the reset GPIO pin and logs the reset action.

- Deactivate Virtual Environment:

    Deactivates the virtual environment and logs this action.

- Log Messages:

    All major actions (like creating virtual environments, installing tools, flashing, etc.) are logged to reprogramming_log.txt.
