## Setting_Up_Raspberry_Pi_Camera
Raspberry Pi Camera module is a high-quality 5 megapixel OV5647 sensor in an adjustable-focus module 

[Ref](https://www.waveshare.com/wiki/RPi_Camera_(B))

![alt text](image.png)

### Software Configuration
If you use the latest Bookworm system, you need to configure /boot/firmware/config.txt.
```sh
#If using the bookworm system
sudo nano /boot/firmware/config.txt

```
Find "camera-auto-detect=1" and modify it to "camera_auto_detect=0".
```sh
camera_auto_detect=0
dtoverlay=ov5647
```

Reboot the Rpi


### Check if camera connected in dmesg
```sh
dmesg | grep ov5647
[    0.054793] platform 3f801000.csi: Fixed dependency cycle(s) with /soc/i2c0mux/i2c@1/ov5647@36
[    5.729878] platform 3f801000.csi: Fixed dependency cycle(s) with /soc/i2c0mux/i2c@1/ov5647@36

```

### Test Camera Commands
Enter the Raspberry Pi terminal and enable the camera to preview:
```sh
sudo libcamera-hello -t 0
```