# Weather Station

## NMEA string format description

### For Wind Direction and Wind Speed:
Format: `$WIMWV,<WindAngle>,<Reference>,<WindSpeed>,<WindSpeedUnits>,<Status>*<ChecksumInHex><CR><LF>`

Example: `$WIMWV,200.9,T,145.0,M,A*2d`

where,
- Reference - `Theoretical(T) / Relative(R)`
- Status - `ValidData(A) / InValidData(V)`
- ChecksumInHex - XOR of each byte lies between `'$'` and `'*'` in HEX

### For Weather Analytics:
Format: `$WIMWA,<RainFall>,<RainFallUnits>*<ChecksumInHex><CR><LF>`

Example: `$WIMWA,12.123,mm*5b`

#### If BME_680 Sensor Installed
Format: `$WIMWA,<RainFall>,<RainFallUnits>,<Temperature>,<TempUnits>,<Pressure>,<PressureUnits>,<Humidity>,<HumidPercent>,<Altitude>,<AltitudeUnits>*<ChecksumInHex><CR><LF>`

Example: `$WIMWA,0.000,mm,30.6,C,946.8,hPa,66.9,%,568.8,m*35`

where,
- ChecksumInHex - XOR of each byte lies between `'$'` and `'*'` in HEX

-----------------------
### System Architecture
![InsectTrap_HW_Arch](Documents/InsectTrap_HW_Arch.jpg)

-----------------------
### [Setting up LTE modem with raspberry pi](Documents/LTE_Modem_Setup.md)
### [Reprogramming ESP32 with Raspberry pi](Documents/Reprogramming_ESP32_with_raspberry_pi.md)
### [Setting_Up_Raspberry_Pi_Camera.md](Documents/Setting_Up_Raspberry_Pi_Camera.md)

### Device List and Features
Host Name | Battery Monitoring | Weather Sensors | Camera | Latching Relay | User Name | Password 
------- | ------ | ------ | ----- | ------ | ------ | ------
dt-rpi-9006 | Yes | Yes | Yes | Yes | delta | D3ltaR0cks
dt-rpi-9007 | Yes | Yes | Yes | Yes | delta | D3ltaR0cks
dt-rpi-9008 | Yes | No | Yes | Yes | delta | D3ltaR0cks
dt-rpi-9009 | Yes | No | Yes | Yes | delta | D3ltaR0cks
dt-rpi-9010 | Yes | No | Yes | Yes | delta | D3ltaR0cks
dt-rpi-9012 | Yes | No | Yes | Yes | delta | D3ltaR0cks
dt-rpi-9013 | Yes | No | Yes | Yes | delta | D3ltaR0cks
dt-rpi-9013 | Yes | Yes | Yes | Yes | delta | D3ltaR0cks