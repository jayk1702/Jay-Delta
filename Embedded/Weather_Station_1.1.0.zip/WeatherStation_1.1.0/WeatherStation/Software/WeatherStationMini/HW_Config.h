#ifndef _HW_CONFIG_H_
#define _HW_CONFIG_H_

#include <Arduino.h>
//#include <Watchdog.h> //https://github.com/janelia-arduino/Watchdog (Peter Polidoro)
//#include "PinChangeInterrupt.h" //by NicoHood

#define NMEA_UPDATE_INTERVAL (10000) //Milliseconds

/*
-------------------------
|   RJ 11 Male Pin OUT  |
| 1 | 2 | 3 | 4 | 5 | 6 |
--------         --------
        |_NOTCH_|
  1: NC
  2: GND
  3: GND
  4: WIND SPEED (Yellow) || RAIN (GREEN)
  5: WIND Direction (Green)
  6: NC
*/
#define RAIN_PIN     15
#define RAINGAUGE_RESET_CMD "$WIRRG,0*"
#define UV_LIGHT_ON "$UVCMD,1*"
#define UV_LIGHT_OFF "$UVCMD,0*"

#define WIND_SPD_PIN 16 //Yellow
#define WIND_DIR_PIN 2 //ESP32S3 GPIO2-ADC1_1 //Green


#define HEARTBEAT_PIN 14
#define STATUS_LED_PIN 38 //On-Board RGB LED

#define RELAY_PIN_A_RPI_POWER  47
#define RELAY_PIN_B_RPI_POWER  48

//pin 10, 11,12 & 13 are being used for SPI: 10 (SS), 11 (MOSI), 12 (MISO), 13 (SCK)
//1.0.1 Battery Management
#define PROG_VER "1.1.0"

#define R1   47.0     // R1=47kohm
#define R2   5.6      // R2 = 5.6kohm
#define REFERENCE_VOLT     3.3
#define RESOLUTION         4096
#define BATTERY_PIN_IN     1 //ESP32S3 GPIO1-ADC1_0

#define BAT_VOLT_OFFSET     240 //mV
#define DIODE_VOLT_DROP     370 //mV

//UV Light
#define UV_LIGHT_EN     42
#define TIME_DURATION   14400000000    // 4 hours

/*
The rain gauge is a self-emptying tipping bucket type. Each 0.011”
(0.2794 mm) of rain causes one momentary contact closure that can
be recorded with a digital counter or microcontroller interrupt input. 
*/
#define RAINFALL_PER_TIPPING_INCH (0.011)
#define RAINFALL_PER_TIPPING_MM (0.2794)
#define MIN_MILLIS_PER_RAINFALL (100)

/*
The cup-type anemometer measures wind speed by closing a contact
as a magnet moves past a switch. A wind speed of 1.492 MPH (2.4
km/h) causes the switch to close once per second. 
*/
#define MPH_WIND_SPEED_REQUIRED_TO_CLOSE_SWITCH_ONCE_PER_SECOND (1.492) //MPH
#define KMPH_WIND_SPEED_REQUIRED_TO_CLOSE_SWITCH_ONCE_PER_SECOND (2.4) //KMPH
#define MPH_TO_MPS (0.44704) // miles per hour to meter per second

#define SEALEVELPRESSURE_HPA (1013.25)

#define SAMPLES            20

//NMEA Data & units
#define INCHES_OF_MERCURY "I"
#define PRESSURE_BARS "B"
#define TEMPERATURE_DEG_C "C"
#define WIND_SPEED_KNOTS "N"
#define WIND_SPEED_MPS "M"
#define WIND_SPEED_KMPH "K"
#define WIND_SPEED_STATUTE_MILESPHOuR "S"
#define RAIN_GUAGE_UNITS "mm"
#define PRESSURE_HECTO_PASCAL "hPa"
#define HUMIDITY_PERCENT "%"
//#define GAS_RESISTANCE_KOHMS "KOhms"
#define ALTITUDE_UNITS "m"
#define MILLI_VOLTAGE_UNITS "mV"

#define WIND_DIR_TRUE "T"
#define WIND_DIR_MAGNETIC "M"
#define RELATIVE "R"
#define THEORETICAL "T"
#define DATA_VALID "A"
#define DATA_INVALID "V"

#define COMMA_SEPARATOR ","
#define PAYLOAD_BEGIN "$"
#define PAYLOAD_ASTERISK "*"
#define PAYLOAD_END "\r\n"

#define SETUP_LED_ON_DURATION  2000
#define SETUP_LED_OFF_DURATION  1000
#define SETUP_LED_ON_IF_NOT_TRIPPED_DURATION  4000
#define SETUP_LED_ON_IF_TRIPPED_DURATION  1500

//Uncomment to add BME-680 capability
#define BME680_INSTALLED

//#define WEATHERSENSOR_INSTALLED

//#define WATCHDOG_ENABLE

#define POWER_MGMNT_ENABLED
#define RESET_RAIN_GAUGE

/*----------------------------MPPT-------------------
* MPPT Charge controller has the the LOWER CUTOFF VOLTAGE of 11V where it disconnects the load while discharging
* While charging it enables the load at 12.7V, below values are considered well above the thresholds of MPPT
* charge controller so device has the safe voltage ranges to shutdown the SOC
*/
#define SAFE_BAT_VOLTAGE_UPPER_THRESHOLD 13000 //mV
#define SAFE_BAT_VOLTAGE_LOWER_THRESHOLD 12000 //mV
#define BAT_VOLATGE_LOW_CRITICAL 11500 //mV

#define BAT_VOLTAGE_SAFE_CHECK_TIMEOUT 10000 //milli seconds
#define HEARTBEAT_RX_TIMEOUT 3000 //milli seconds
#define RPI_BOOTUP_TIMEOUT 60000 //milli seconds

typedef enum 
{
  EN_INIT_SHUTDOWN_SEQ_NA = 0,
  EN_INIT_SHUTDOWN_SEQ_BAT_LOW = 1, // 12V
  EN_INIT_SHUTDOWN_SEQ_BAT_CRITICAL = 2, // 11.5
}En_ShutdownSeqReq;
//Serial Debug
//#define ENABLE_SERIAL_DEBUG
//#define ENABLE_SERIAL_DEBUG_PM

#pragma pack(1)
struct WIMWV_Payload_S{
  float windAngle;
  // Reference;
  float windSpeed;
  // windSpeedUnits;
  String windDir;
  // Status;
};

#pragma pack(1)
struct WIMWA_Payload_S{
  float rainGuage_RainFall;
  //float rainGuage_LastHour;
  // Units;
  //float rainGuage_LastDay;
  // Units;
  //float rainGuage_TillDate;
  // Units;
#ifdef BME680_INSTALLED
  float bme680_Temperature;
  //Units;
  float bme680_Pressure;
  //Units;
  float bme680_Humidity;
  //Units
  //float bme680_Gas;
  //units
  float bme680_Altitude;
  //Units
#endif //BME680_INSTALLED
};

#pragma pack(1)
struct WIMDT_Payload_S{
  int batmV;
  // batVoltUnits;
};


#endif //_HW_CONFIG_H_