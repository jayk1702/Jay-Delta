#include "HW_Config.h"


void InitLCDModule(void);
void DisplayAnalytics(En_BaleInformation);
String GetMachineTypeStr(En_BalerMachineType);
