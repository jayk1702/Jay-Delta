#include "HW_Config.h"



void TransmitPayloadOverSerial(En_DevDataType);
int PayloadChecksumCalculate(String);
